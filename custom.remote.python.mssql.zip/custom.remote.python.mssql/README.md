# Microsoft SQL Server Extension

Remote monitoring extension running on Environment ActiveGate.

## Download extension

http://extensions.dynatrace.sh

Credentials:
* Login: `extensions`
* Password: `dynatrace2021`

## Documentation

https://www.dynatrace.com/support/help/technology-support/application-software/other-technologies/dynatrace-extension-required/ms-sql/
