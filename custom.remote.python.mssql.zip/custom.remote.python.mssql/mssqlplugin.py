import os
import json
import logging
import jaydebeapi
import jpype

from ruxit.api.exceptions import AuthException, ConfigException

from segestre import Segestre, CommandLineApp
from typing import Dict, List, Tuple, Any

# TODO

# DONE
# 1. Rewrite JDBC connection url
# 3. Create separate query for each metric as a workaround
# 2. Rewrite collection logic

PERF_COUNTER_LARGE_RAWCOUNT = 65792
PERF_COUNTER_COUNTER = 272696320
PERF_AVERAGE_BULK_ABSOLUTE = 537003264

PERF_COUNTER_BULK_COUNT = 272696576
PERF_AVERAGE_BULK_RELATIVE = 1073874176
PERF_LARGE_RAW_BASE = 1073939712

VALID_COUNTER_TYPES = (
    PERF_COUNTER_LARGE_RAWCOUNT,
    PERF_COUNTER_COUNTER,
    PERF_AVERAGE_BULK_ABSOLUTE,
    PERF_COUNTER_BULK_COUNT,
    PERF_AVERAGE_BULK_RELATIVE,
    PERF_LARGE_RAW_BASE
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class RemoteMsSqlPlugin(Segestre):
    def __init__(self, *args, **kwargs):
        logger.info("Initializing RemoteMsSqlPlugin")

        # Obtain settings from JSON file in the same dir
        path = os.path.abspath(os.path.join(
            os.path.dirname(__file__), "settings.json"))
        with open(path, "r") as f:
            logger.info(f"Reading settings from {path}")
            settings_data = f.read()
            settings = json.loads(settings_data)

        # Initialize segestre and remote plugin base classes
        super().__init__(*args, **kwargs, settings=settings)

        # Boot JVM that will execute queries
        self._start_jvm()

    def collect(self) -> None:
        logger.info("Collecting raw metrics from the database")
        # Collect result sets for each query from database
        queries = [
            (q, self.settings["queries"][q])
            for q in sorted(self.settings["queries"].keys())
        ]

        # This is a generator object that yileds results for each query
        query_results = self._execute_queries(queries)

        # For each executed query
        for query_name, column_names, rs in query_results:
            dimension_keys = self.settings["queries"][query_name]["dimensions"]

            for row in rs:
                # Extract raw values from row into a dictionary in form of
                #    { column_name: value, ... }
                mapping = {str(c).lower(): row[i]
                           for i, c in enumerate(column_names)}

                # Skip non-relative and non-absolute counters
                if mapping["cntr_type"] not in VALID_COUNTER_TYPES:
                    continue

                values = {mapping["counter_name"].strip(): mapping["cntr_value"]}

                # If dimension is part of the query
                if "instance_name" in mapping:
                    values["instance_name"] = mapping["instance_name"]

                self.store(query_name, dimension_keys, values)

    def build_group_and_device_name(self) -> str:
        """Builds unique name to identify custom device"""
        c = self.settings["connection"]

        group_name = f"{c['database_host']}:{c['database_port']}"
        device_name = f"{c['database_name']}"
        return group_name, device_name

    def _build_jdbc_connection_params(self):
        c = self.settings["connection"]

        # Build connection parameters
        classname = c["jclassname"]
        url = f"{c['database_driver']}://{c['database_host']}:{c['database_port']}"

        driver_args = {
            "databaseName": c["database_name"],
            "user": c["database_user"],
            "password": c["database_password"]
        }

        # Log obtainer connection parameters
        logger.info(f"Connection class name: {classname}")
        logger.info(f"Connection url: {url}")
        logger.info(
            f"Connection args: {driver_args['databaseName']}, {driver_args['user']}, '********']")

        return classname, url, driver_args

    def _execute_queries(self, queries: List[Tuple[str, Any]]) -> None:
        logger.info("Executing queries")
        connection = cursor = None

        try:
            connection = jaydebeapi.connect(
                *self._build_jdbc_connection_params())
            logger.info("Connection created")
            cursor = connection.cursor()
            logger.info("Cursor obtained from connection")

            for key, q in queries:
                if q["enabled"]:
                    dbname = self.settings["connection"]["database_name"]
                    clause = (
                        f"instance_name = '{dbname}'"
                        if self.settings["connection"]["single_database"]
                        else "instance_name != '_Total'"
                    )
                    sql = q["sql"].format(instance_name_condition=clause)

                    logger.info(f"Executing query '{key}': {sql}")

                    cursor.execute(sql)

                    rs = cursor.fetchall()
                    num_rows_fetched = len(rs) if rs else -1
                    logger.info(f"Rows fetched: {num_rows_fetched}")
                    # https://www.python.org/dev/peps/pep-0249/#description
                    column_names = [c[0] for c in cursor.description]

                    yield key, column_names, rs

                else:
                    logger.info(f"Skipping disabled query: {key}")

        except Exception as e:
            logger.exception(e)
            raise e

        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

    def _start_jvm(self) -> None:
        jdbc_jar_name = self.settings["connection"]["jarpath"]
        jdbc_jar_path = os.path.abspath(os.path.join(
            os.path.dirname(__file__), jdbc_jar_name))
        logger.info(f"Using jdbc jar: {jdbc_jar_path}")

        # Check that JVM exists somewhere. Otherwise we won't be able to
        # run JayDeBeApi
        java_home = os.environ.get("JAVA_HOME", None)
        if not java_home and not self._find_jvm_path():
            raise ConfigException(
                "Unable to find JVM required for JDBC to run")

        # If JAVA_HOME is set, then try to find JVM in standard JAVA_HOME locations.
        # Otherwise search in predefined paths.
        jvm_path = jpype.getDefaultJVMPath() if java_home else self._find_jvm_path()
        jvm_args = f"-Djava.class.path={jdbc_jar_path}"
        logger.info(f"Found JVM at: {jvm_path}")

        try:
            logger.info(f"Attempting to start JVM at: {jvm_path}")
            jpype.startJVM(jvm_path, jvm_args, convertStrings=True)

        except OSError as ose:
            # Do not react to errors of JVM is already started for Jpype
            logger.exception(
                f"Ignoring OSError exception while starting JVM: {ose}")
            logger.error(
                f"Details: strerror: {ose.strerror}, args: {ose.args}, fn1: {ose.filename}, fn2: {ose.filename2}, errno: {ose.errno}")
            #raise ConfigException(f"Could not start JVM: {ose}")

        except Exception as e:
            logger.exception(
                f"Unknown exception while trying to start JVM: {e}")
            raise ConfigException(f"Could not start JVM: {e}")

    def _find_jvm_path(self):
        paths = [
            "/usr/lib/jvm",
            "../../../gateway/jre/bin/server/jvm.dll",
            "../../../gateway/jre/lib/server/libjvm.so",
            "../../../gateway/jre/lib/amd64/server/libjvm.so",
            "../../../jre/bin/server/jvm.dll",
            "../../../jre/lib/amd64/server/libjvm.so",
            "C:/Program Files/Dynatrace/gateway/jre/bin/server/jvm.dll",
            "/opt/dynatrace/gateway/jre/lib/server/libjvm.so",
            "/opt/dynatrace/gateway/jre/lib/amd64/server/libjvm.so"
        ]

        gateway_home = os.environ.get("GATEWAY_HOME", None)
        if gateway_home:
            paths.append(f"{gateway_home}/jre/bin/server/jvm.dll")
            paths.append(f"{gateway_home}/jre/bin/server/libjvm.so")

        for p in paths:
            if os.path.isfile(p):
                return p

        return None


def cli():
    logging.basicConfig(level=logging.DEBUG)
    app = CommandLineApp(RemoteMsSqlPlugin(
        results_builder=None, topology_builder=None))
    app.run()


if __name__ == "__main__":
    cli()
