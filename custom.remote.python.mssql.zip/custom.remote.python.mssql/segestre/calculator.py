import logging
from collections import defaultdict
from typing import Dict
from importlib import import_module

from segestre.storage import Storage
from segestre.exceptions import NotEnoughValues


logger = logging.getLogger(__name__)


class Calculator:
    def __init__(self, settings, storage):
        self.propogation_counter = 0
        self.settings = settings
        self.storage = storage

    def calculate(self, evaluation_limit: int = 100) -> None:
        logger.info("Calculating metrics")

        # Increase propogation counter
        self.propogation_counter += 1

        # Form a queue out of all metrics
        queue = list(self.settings["metrics"].keys())

        # Count how many times each metric was evaluated
        evaluation_history = defaultdict(lambda: defaultdict(lambda: 0))

        # Infuse dimensions with necessary calculation libs
        for d in self.storage:
            self.storage[d]["datetime"] = getattr(
                import_module("datetime"), "datetime")
            self.storage[d]["math"] = import_module("datetime")

        # Go over each metric in the queue and make sure it's calculated
        while queue:
            # Pop first element
            key = queue.pop(0)
            m = self.settings["metrics"][key]

            # Execute a formula from config for each dimension
            formula = m["formula"]
            requested_dimensions = m["dimensions"]

            # For each dimension
            for d in self.storage:
                # Check if this dimension combination was reequested to be reported by metric
                if {e[0] for e in d} != set(requested_dimensions):
                    # Ignore this dimension combination entirely if is is not requested for the metric
                    continue

                # Remember that we are evaluating this metric and check that we did not exceed
                # the reevaluation limit for this particular metric
                evaluation_history[d][key] += 1
                if evaluation_history[d][key] > evaluation_limit:
                    logger.error(
                        f"Metric evaluation threshold exceeded for '{key}' within '{d}'")
                    break

                # Attempt to calculate the metric based on existing data for particular dimension
                try:
                    logger.debug(f"Attempt evaluating '{key}' in {d}")
                    value = eval(formula, globals(), self.storage[d])

                    logger.debug(f"Evaluated {key} to {value}")
                    self.storage[d][Storage.default_source][key].latest = value

                    # Now, for each unit
                    if "units" in m:
                        for u in m["units"]:
                            unit = u["unit"]
                            name = f"{key}{unit}"

                            # Logic for Units
                            if unit == "Percent":
                                value *= 100
                            else:
                                pass
                                #raise SyntaxError(f"Unknown unit name '{unit}' in metric description")

                            logger.debug(
                                f"Evaluated {name} to {value} within '{d}'")
                            self.storage[d][Storage.default_source][name].latest = value

                except SyntaxError as se:
                    logger.exception((
                        "Evaluation syntax error for metric "
                        f"'{key}' in formula '{formula}': {str(se)}"
                    ))
                    raise se

                except NameError as ne:
                    # Not all values required for this metric to be calculated
                    # are present in the storage. Thus, we put the metric back to the
                    # end of the queue.
                    logger.error(f"NameError for {key}: {ne}")
                    queue.append(key)

                except NotEnoughValues:
                    # Do not put value back for this cycle
                    logger.debug(f"NotEnoughValues for {key}")
                    # Add metric back to the queue if we have propogated more 2 or more times.
                    # That would mean we have at least 2 data points in storage to work with.
                    if self.propogation_counter > 1:
                        queue.append(key)
