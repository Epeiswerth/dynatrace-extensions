import logging

from json import dumps


class PluginBuilder:
    def __init__(self, settings):
        self.settings = settings

    def build(self) -> str:

        properties, config_ui = self.build_config_ui()
        metrics = self.build_metrics()
        charts = self.build_charts()

        definition = self.settings["definition"]
        definition["metrics"] = metrics
        definition["properties"] = properties
        definition["configUI"] = config_ui
        definition["ui"] = charts

        s = dumps(definition, indent=2)
        return s

    def build_config_ui(self):
        properties = list()
        config_ui = dict(
            displayName=self.settings["ui"]["name"],
            properties=list()
        )

        display_order = 0
        for key, p in self.settings["properties"].items():

            # Build property
            property = {"key": key, "type": p["type"]}
            if "defaultValue" in p:
                property["defaultValue"] = p["defaultValue"]
            properties.append(property)

            # Build config UI element
            config_ui_element = {
                "key": key,
                "displayName": p["displayName"],
                "displayOrder": p["displayOrder"],
            }
            config_ui["properties"].append(config_ui_element)
            display_order = max(p["displayOrder"], display_order)

        # Add all metrics as on/off reporting switches
        for key, m in self.settings["metrics"].items():

            if "units" in m:
                for u in m["units"]:
                    name = f"{key}{u['unit']}"
                    display_order += 1
                    properties.append({
                        "key": name,
                        "type": "Boolean",
                        "defaultValue": u["reported"]
                    })
                    config_ui["properties"].append({
                        "key": name,
                        "displayName": f"Collect {name}",
                        "displayOrder": display_order
                    })
            
            elif "states" in m:
                display_order += 1
                properties.append({
                    "key": key,
                    "type": "Boolean",
                    "defaultValue": m["reported"]
                })
                config_ui["properties"].append({
                    "key": key,
                    "displayName": f"Collect {key}",
                    "displayOrder": display_order
                })

        return properties, config_ui

    def build_metrics(self):
        metrics = list()

        # Special case for availability of the custom device
        metrics.append({
            "entity": "CUSTOM_DEVICE",
            "timeseries": {
                "key": "AvailabilityPercent",
                "unit": "Percent",
                "dimensions": [],
                "displayname": "Availability (Percent)",
            }
        })

        # Add all other metrics
        for key, m in self.settings["metrics"].items():
            entity = (
                "CUSTOM_DEVICE_GROUP" 
                if "group_metric" in m and m["group_metric"]
                else "CUSTOM_DEVICE"
            )

            if "units" in m:
                for u in m["units"]:
                    metrics.append({
                        "entity": entity,
                        "timeseries": {
                            "key": f"{key}{u['unit']}",
                            "unit": u["unit"],
                            "dimensions": m["dimensions"],
                            "displayname": f"{key} ({u['unit']})"
                        }
                    })
            
            elif "states" in m:
                metrics.append({
                    "entity": entity,
                    "statetimeseries": {
                        "key": key,
                        "states": [s["name"] for s in m["states"]],
                        "dimensions": m["dimensions"],
                        "displayname": key
                    }
                })

        return metrics

    def build_charts(self):
        ui = dict(
            keymetrics=list(),
            keycharts=list(),
            charts=list()
        )

        # Add main key metrics
        ui["keymetrics"] = self.settings["ui"]["keymetrics"]

        # Add all other charts
        for t in self.settings["ui"]["tabs"]:
            keychart = "key" in t and t["key"] is True

            for c in t["charts"]:
                c["group"] = t["tab"]
                if keychart:
                    ui["keycharts"].append(c)
                else:
                    ui["charts"].append(c)

        return ui

    def save(self, plugin: str, path: str) -> None:
        with open(path, "w") as f:
            f.write(plugin)
