import logging

from typing import Dict, Tuple, List, Optional

Header = List[str]
Row = List[str]
Rows = List[Row]
Table = Tuple[Header, Rows]


def print_table(table: Table) -> None:
    headers, rows = table
    lengths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            lengths[i] = len(c) if len(c) > lengths[i] else lengths[i]

    headers_row = ""
    for i, h in enumerate(headers):
        headers_row += h.ljust(lengths[i] + 1, " ")
    print(headers_row)

    separator_row = ""
    for n in lengths:
        separator_row += "=" * n + " "
    print(separator_row)

    for r in rows:
        row = ""
        for i, c in enumerate(r):
            row += c.ljust(lengths[i] + 1, " ")
        print(row)


def dict_to_table(
    d: Dict,
    headers: List[str] = ["Name", "Value"],
    indentation: str = "  ",
    limit: int = 0,
) -> Table:
    """
    Transform multilevel dictionary into table structure suitable for printing by Cleo library.
    """

    def processor(c: Dict, rows: Rows, level: int):
        # Increment level so that all child rows are indented
        level += 1
        for k in sorted(c.keys()):
            if limit and len(rows) >= limit:
                break

            # Format the key properly
            if type(k) is frozenset:
                # Special case for nices printing of frozenset
                key = _dimensions_to_str(k)
            else:
                key = k
            table_key = f"{indentation * level}{key}"

            # Try to interpret the field as a dictionary
            try:
                # Can't do isinstance(c, collections.Mapping) because
                # config that needs this method is not a Mapping subclass
                is_dict = hasattr(c[k], "keys")
            except KeyError:
                is_dict = False

            if is_dict:
                # Add category row
                rows.append([table_key, ""])
                # Recursive call
                processor(c[k], rows, level)

            else:
                # Transform multiline strings into singleline
                singleline = " ".join(
                    str(c[k]).replace("\n", " ").replace("\t", " ").split()
                )

                # Clip long string by character limit to fit onto the screen
                clipped = (
                    singleline if len(singleline) < 80 else f"{singleline[:76]} ..."
                )
                rows.append([table_key, clipped])

    # Populate rows
    rows = []
    processor(d, rows, -1)
    if limit and len(rows) >= limit:
        rows.append(["...", "..."])

    return (headers, rows)


def _dimensions_to_str(s: frozenset) -> str:
    """
    Return nicer representation of frozenset with dimensions to string
    """
    return ", ".join([str(d) for d in s])
